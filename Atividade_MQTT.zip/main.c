#include <stdio.h>
#include <string.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <driver/gpio.h>
#include <esp_log.h>
#include <freertos/queue.h>
#include "nvs_flash.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "wifi.h"
#include "mqtt.h"
#include "dht11.h"


// Definindo o número de amostras para o cálculo da média

#define AMOSTRAS 10


// Declarando as variaveis das filas
QueueHandle_t fila_temp, fila_humid, media_movel_temp, media_movel_humid;

// Declarando as variaveis dos semáforos

SemaphoreHandle_t sem_bin1, sem_bin2;
SemaphoreHandle_t wificonnectedSemaphore;
SemaphoreHandle_t mqttconnectedSemaphore;


void wifiConnected(void *params)
{
    while (1)
    {
        if (xSemaphoreTake(wificonnectedSemaphore, portMAX_DELAY))
        {
            mqtt_start();
        }
    }
}


void comunicacao_broker(void *params)
{
    float temp_media, humid_media;
    char msg[20]; 

    xSemaphoreTake(mqttconnectedSemaphore, portMAX_DELAY);

    while (1)
    {
        // Publica temperatura média
        if (xQueueReceive(media_movel_temp, &temp_media, pdMS_TO_TICKS(1000)))
        {
            sprintf(msg, "%.2f", temp_media);
            mqtt_publish("CEL080B/Sensores/BancadaB/Temperatura", msg);
            ESP_LOGI("MQTT", "Temp média: %.2f", temp_media);
        }
        
        // Publica umidade média
        if (xQueueReceive(media_movel_humid, &humid_media, pdMS_TO_TICKS(1000)))
        {
            sprintf(msg, "%.2f", humid_media);
            mqtt_publish("CEL080B/Sensores/BancadaB/Umidade", msg);
            ESP_LOGI("MQTT", "Umid média: %.2f", humid_media);
        }
        
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}


void Coleta(void *pvparameters)
{
    ESP_LOGI("Coleta", "task inicializando");
    struct dht11_reading data1;
    int contador = 0;
    while (1)
    {
 
        data1 = DHT11_read();
        xQueueSendToBack(fila_temp, &data1.temperature, portMAX_DELAY);
        xQueueSendToBack(fila_humid, &data1.humidity, portMAX_DELAY);

        contador++;
        
        // Verifica se já coletou 10 amostras, se sim, libera o semáforo para calcular a média
        if(contador >= AMOSTRAS)
        {
            contador = 0;
            xSemaphoreGive(sem_bin1);
        }


       vTaskDelay(pdMS_TO_TICKS(1000));    
    }
    
}


void Media_Temp(void *pvparameters)
{
    ESP_LOGI("Media Temperatura", "task inicializando");
    float temp[AMOSTRAS];
    float media;
    struct dht11_reading data;
    while(1)
    {
        xSemaphoreTake(sem_bin1, portMAX_DELAY);

        if(uxQueueMessagesWaiting(fila_temp) < AMOSTRAS)
        {
            xSemaphoreGive(sem_bin1);
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
        else
        {   
            media = 0;
            // armazena os 10 valores da fila em um vetor
            for(int i = 0; i < AMOSTRAS; i++)
            {
                xQueueReceive(fila_temp, &data, portMAX_DELAY);
                temp[i] = data.temperature;
            }

            // realiza o somatório
            for(int i = 0; i < AMOSTRAS; i++)
            {
                media += temp[i];
            }

            // calcula a média
            media = media / AMOSTRAS;
            xQueueSendToBack(media_movel_temp, &media, portMAX_DELAY);
            xSemaphoreGive(sem_bin2);
            xSemaphoreGive(sem_bin1);
        }
    }
}

void Media_Humid(void *pvparameters)
{
    ESP_LOGI("Media Humidade", "task inicializando");
    float humid[AMOSTRAS];
    float media;
    struct dht11_reading data;
    while(1)
    {
        xSemaphoreTake(sem_bin2, portMAX_DELAY);
        // Verifica se a fila possui 10 valores para calcular a média

        if(uxQueueMessagesWaiting(fila_humid) < AMOSTRAS)
        {
            xSemaphoreGive(sem_bin2);
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
        else
        {   
            media = 0;
            // armazena os 10 valores da fila em um vetor
            for(int i = 0; i < AMOSTRAS; i++)
            {
                xQueueReceive(fila_humid, &data, portMAX_DELAY);
                humid[i] = data.humidity;
            }

            // realiza o somatório
            for(int i = 0; i < AMOSTRAS; i++)
            {
                media += humid[i];
            }

            // calcula a média
            media = media / AMOSTRAS;
            xQueueSendToBack(media_movel_humid, &media, portMAX_DELAY);
            xSemaphoreGive(sem_bin2);
        }

        

    }
    
}






void app_main(void)
{
    // Setando a prioridade da tarefa principal para 5
    vTaskPrioritySet(NULL, 5);

    // Configurando o pino do DHT11 como entrada com pull-up
    gpio_set_pull_mode(DHT11_PIN, GPIO_PULLUP_ONLY);
    // Inicializando o DHT11
    DHT11_init(DHT11_PIN);
    
    // Inicializando o NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    // Criando semáforos binários
    wificonnectedSemaphore = xSemaphoreCreateBinary();
    mqttconnectedSemaphore = xSemaphoreCreateBinary();
    sem_bin1 = xSemaphoreCreateBinary();
    sem_bin2 = xSemaphoreCreateBinary();


    // Criando filas
    fila_temp = xQueueCreate(50, sizeof(float));
    fila_humid = xQueueCreate(50, sizeof(float));
    media_movel_temp = xQueueCreate(10, sizeof(float));
    media_movel_humid = xQueueCreate(10, sizeof(float));

    // Iniciando o Wi-Fi
    wifi_start();
    
    // Criando tarefas
    xTaskCreate(wifiConnected, "Conexao MQTT", 4096, NULL, 2, NULL);
    xTaskCreate(comunicacao_broker, "Comunicacao com o Broker", 4096, NULL, 2, NULL);

    xTaskCreate(Coleta, "TASK Coleta", 2048, NULL, 4, NULL);
    xTaskCreate(Media_Temp, "TASK Media", 2048, NULL, 3, NULL);
    xTaskCreate(Media_Humid, "TASK Display", 2048, NULL, 3, NULL);

}




